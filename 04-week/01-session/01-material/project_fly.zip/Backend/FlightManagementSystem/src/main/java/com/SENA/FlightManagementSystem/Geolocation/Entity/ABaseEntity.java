package com.SENA.FlightManagementSystem.Geolocation.Entity;

public abstract class ABaseEntity {
    // Métodos y atributos comunes para entidades
}
