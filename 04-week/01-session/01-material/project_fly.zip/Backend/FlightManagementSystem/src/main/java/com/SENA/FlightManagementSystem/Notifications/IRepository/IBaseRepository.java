package com.SENA.FlightManagementSystem.Notifications.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
