package com.SENA.FlightManagementSystem.Parameterization.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
