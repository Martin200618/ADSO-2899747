package com.SENA.FlightManagementSystem.Parameterization.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
