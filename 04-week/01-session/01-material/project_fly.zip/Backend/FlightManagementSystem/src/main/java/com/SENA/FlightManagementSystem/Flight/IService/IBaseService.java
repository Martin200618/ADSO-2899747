package com.SENA.FlightManagementSystem.Flight.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
