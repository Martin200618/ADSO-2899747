package com.SENA.FlightManagementSystem.HumanResources.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
