package com.SENA.FlightManagementSystem.Infrastructure.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
