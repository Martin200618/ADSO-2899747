package com.SENA.FlightManagementSystem.Geolocation.Controller;

public abstract class ABaseController {
    // Métodos y atributos comunes para controladores
}
