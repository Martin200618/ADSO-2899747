package com.SENA.FlightManagementSystem.Security.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
