package com.SENA.FlightManagementSystem.AircraftManagement.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
