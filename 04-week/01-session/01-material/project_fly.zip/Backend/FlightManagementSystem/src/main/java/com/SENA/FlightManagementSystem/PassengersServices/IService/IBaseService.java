package com.SENA.FlightManagementSystem.PassengersServices.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
