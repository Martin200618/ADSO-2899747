package com.SENA.FlightManagementSystem.PassengersServices.Controller;

public abstract class ABaseController {
    // Métodos y atributos comunes para controladores
}
