package com.SENA.FlightManagementSystem.HumanResources.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
