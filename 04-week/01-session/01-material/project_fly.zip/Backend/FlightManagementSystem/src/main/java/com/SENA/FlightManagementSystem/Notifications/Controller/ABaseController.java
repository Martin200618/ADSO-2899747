package com.SENA.FlightManagementSystem.Notifications.Controller;

public abstract class ABaseController {
    // Métodos y atributos comunes para controladores
}
