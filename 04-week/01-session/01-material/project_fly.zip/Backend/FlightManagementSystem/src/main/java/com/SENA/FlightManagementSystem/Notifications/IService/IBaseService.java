package com.SENA.FlightManagementSystem.Notifications.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
