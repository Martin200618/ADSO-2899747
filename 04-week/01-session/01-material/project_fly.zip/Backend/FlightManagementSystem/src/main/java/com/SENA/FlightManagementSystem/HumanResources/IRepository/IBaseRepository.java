package com.SENA.FlightManagementSystem.HumanResources.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
