package com.SENA.FlightManagementSystem.Parameterization.Entity;

public abstract class ABaseEntity {
    // Métodos y atributos comunes para entidades
}
