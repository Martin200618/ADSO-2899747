package com.SENA.FlightManagementSystem.HumanResources.Entity;

public abstract class ABaseEntity {
    // Métodos y atributos comunes para entidades
}
