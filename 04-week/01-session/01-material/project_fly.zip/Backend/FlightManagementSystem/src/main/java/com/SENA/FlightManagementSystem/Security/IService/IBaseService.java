package com.SENA.FlightManagementSystem.Security.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
