package com.SENA.FlightManagementSystem.Parameterization.IService;

import com.SENA.FlightManagementSystem.Parameterization.Entity.CrewRole;

public interface ICrewRoleService extends IBaseService<CrewRole> {
    
}
