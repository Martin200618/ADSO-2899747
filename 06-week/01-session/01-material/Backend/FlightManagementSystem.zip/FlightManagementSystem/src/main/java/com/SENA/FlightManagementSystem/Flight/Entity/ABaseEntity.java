package com.SENA.FlightManagementSystem.Flight.Entity;

public abstract class ABaseEntity {
    // Métodos y atributos comunes para entidades
}
