package com.SENA.FlightManagementSystem.Parameterization.IRepository;
import com.SENA.FlightManagementSystem.Parameterization.Entity.DocumentType;

public interface IDocumentTypeRepository extends IBaseRepository<DocumentType, String> {
    
}
