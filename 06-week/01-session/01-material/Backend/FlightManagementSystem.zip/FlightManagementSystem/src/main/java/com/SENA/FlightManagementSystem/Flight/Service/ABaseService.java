package com.SENA.FlightManagementSystem.Flight.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
