package com.SENA.FlightManagementSystem.PassengersServices.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
