package com.SENA.FlightManagementSystem.Infrastructure.Entity;

public abstract class ABaseEntity {
    // Métodos y atributos comunes para entidades
}
