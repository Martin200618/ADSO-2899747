package com.SENA.FlightManagementSystem.Security.Entity;

public abstract class ABaseEntity {
    // Métodos y atributos comunes para entidades
}
