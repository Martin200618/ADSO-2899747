package com.SENA.FlightManagementSystem.Parameterization.IService;

import com.SENA.FlightManagementSystem.Parameterization.Entity.FlightType;

public interface IFlightTypeService extends IBaseService<FlightType> {
    
}
