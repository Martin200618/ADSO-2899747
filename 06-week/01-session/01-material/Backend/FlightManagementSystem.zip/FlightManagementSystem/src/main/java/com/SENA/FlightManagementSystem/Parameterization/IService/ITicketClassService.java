package com.SENA.FlightManagementSystem.Parameterization.IService;

import com.SENA.FlightManagementSystem.Parameterization.Entity.TicketClass;

public interface ITicketClassService extends IBaseService<TicketClass> {
    
}
