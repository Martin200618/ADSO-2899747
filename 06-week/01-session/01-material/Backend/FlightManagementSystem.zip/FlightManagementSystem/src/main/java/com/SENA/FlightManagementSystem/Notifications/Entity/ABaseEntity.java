package com.SENA.FlightManagementSystem.Notifications.Entity;

public abstract class ABaseEntity {
    // Métodos y atributos comunes para entidades
}
