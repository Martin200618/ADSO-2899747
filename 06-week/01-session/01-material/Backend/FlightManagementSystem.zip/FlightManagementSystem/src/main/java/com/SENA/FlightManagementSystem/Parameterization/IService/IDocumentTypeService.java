package com.SENA.FlightManagementSystem.Parameterization.IService;

import com.SENA.FlightManagementSystem.Parameterization.Entity.DocumentType;

public interface IDocumentTypeService extends IBaseService<DocumentType> {
    
}
