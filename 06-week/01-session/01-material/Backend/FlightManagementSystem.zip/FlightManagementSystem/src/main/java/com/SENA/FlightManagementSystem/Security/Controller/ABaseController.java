package com.SENA.FlightManagementSystem.Security.Controller;

public abstract class ABaseController {
    // Métodos y atributos comunes para controladores
}
