package com.SENA.FlightManagementSystem.Parameterization.IService;

import com.SENA.FlightManagementSystem.Parameterization.Entity.AircraftType;

public interface IAircraftTypeService extends IBaseService<AircraftType> {
    
}
