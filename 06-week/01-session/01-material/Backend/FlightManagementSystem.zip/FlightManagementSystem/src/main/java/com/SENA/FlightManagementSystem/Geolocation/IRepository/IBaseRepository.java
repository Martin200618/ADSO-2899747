package com.SENA.FlightManagementSystem.Geolocation.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
